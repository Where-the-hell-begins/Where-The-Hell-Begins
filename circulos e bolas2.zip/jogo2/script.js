function criarBola() {
  const bola = document.createElement("div");
  bola.classList.add("bola");

  const circulo = document.createElement("div");
  circulo.classList.add("circulo");

  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;

  const x = Math.random() * (screenWidth - 100);
  const y = Math.random() * (screenHeight - 100);

  bola.style.left = `${x}px`;
  bola.style.top = `${y}px`;

  circulo.style.left = `${x}px`;
  circulo.style.top = `${y}px`;

  document.body.appendChild(circulo);
  document.body.appendChild(bola);

  setTimeout(() => {
    bola.remove();
  }, 4000);

  setTimeout(() => {
    circulo.remove();
  }, 3500);

  var delay = Math.random() * 1000 + 500;
  setTimeout(criarBola, delay);
}
criarBola();
